
function apostarAgora() {
    alert("Funcionalidade de apostas em breve!");
}
